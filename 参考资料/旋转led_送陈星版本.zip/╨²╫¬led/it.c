#include "it.h"
#include "led.h"
#include "disp.h"
#include "pattern.h"
//#include "zimo.h"

void exit0_init(void)
{
    IT0 = 1;                        //set INT0 int type (1:Falling 0:Low level)
    EX0 = 1;                        //enable INT0 interrupt
    EA = 1;                         //open global interrupt switch	
}


void exit0_irq(void) interrupt 0   // Ϊ�˱�֤��ʾ���Ե�ͬ��, ����д���ж���
{
//	roll_left_1_line(IMISSYOU, IMISSYOU_SIZE, 0, BUF_SIZE/2);
//	disp(BUF, BUF_SIZE);	
}





