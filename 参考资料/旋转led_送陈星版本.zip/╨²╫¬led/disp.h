#ifndef __DISP_H__
#define __DISP_H__
#include "stc12c56xx.h"


void disp(unsigned char *p, unsigned int size);
void disp_delay(unsigned int cnt);


#endif




/*************************** End of file ****************************/