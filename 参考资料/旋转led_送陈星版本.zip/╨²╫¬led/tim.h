#ifndef __TIM_H__
#define __TIM_H__
#include "stc12c56xx.h"


void tim0_init(void);









#endif

