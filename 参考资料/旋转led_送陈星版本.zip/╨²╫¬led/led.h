#ifndef __LED_H__
#define __LED_H__
#include "stc12c56xx.h"

sbit ledr1  = P2^0;
sbit led1  = P3^3;
sbit led2  = P2^1;
sbit led3  = P3^4;
sbit led4  = P1^6;
sbit led5  = P1^3;
sbit led6  = P2^5;
sbit led7  = P2^4;
sbit led8  = P3^5;
sbit led9  = P2^7;
sbit led10 = P1^2;
sbit led11 = P1^4;
sbit led12 = P2^6;
sbit led13 = P1^0;
sbit led14 = P1^5;
sbit led15 = P3^7;
sbit led16 = P1^7;
sbit ledr2 = P1^1;


void delay(unsigned int i);
void led_disp(unsigned int num);


#endif




/*************************** End of file ****************************/
