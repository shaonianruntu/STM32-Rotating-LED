#ifndef __PATTERN_H__
#define __PATTERN_H__
#include "stc12c56xx.h"



/* buffer size for display, maximum support 10 16x16 characters. */
#define DISPLAY_BUFFER_SIZE			(32*10)	




#define BUF_SIZE		(sizeof(BUF) / sizeof(BUF[0]))

extern unsigned char BUF[DISPLAY_BUFFER_SIZE];



typedef enum
{
	ERROR = 0,
	HANDLING,
	COMPLETE
}
patt_sta;


typedef enum
{
  ROLL_IN = 1,
  ROLL_OUT
}
patt_mode;

void clr_buf(void);
void clr_line(unsigned int sl, unsigned int el);
void copy_to_buf(unsigned char *src, unsigned char *dst, unsigned int cnt);
patt_sta roll_left_1_line(unsigned char *p, unsigned int size, patt_mode mode, unsigned int sl, unsigned int el);
patt_sta roll_right_1_line(unsigned char *p, unsigned int size, patt_mode mode, unsigned int sl, unsigned int el);
void roll_down_1_line(unsigned char *p, patt_mode mode, unsigned int sl, unsigned int el);
void roll_up_1_line(unsigned char *p, patt_mode mode, unsigned int sl, unsigned int el);
unsigned char get_mid(unsigned int size);

#endif



/*************************** End of file ****************************/