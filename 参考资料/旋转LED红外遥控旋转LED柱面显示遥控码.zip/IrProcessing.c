
#include "rotatingled.h"


uchar  irtime;//������ȫ�ֱ���
bit new_code;
uchar IRcord[2];
uchar irdata[17];
uchar key_code;
/************************************************/
void tim1_isr (void) interrupt 3 using 1//��ʱ��1�жϷ�����
{
  irtime++;
}
/*************************************************************/
//�ⲿ�ж�1�������
void ex1_isr (void) interrupt 2 using 2//�ⲿ�ж�1������
{
    static uchar i,p,z;
    static bit startflag;
    TR1=1;
    if(startflag)
    {        
        if(irtime<100&&irtime>=53)//������ TC9012��ͷ��
        { 
            i=0;
            p=1;
            z=0;
            irdata[i]=irtime;
            irtime=0;
        }
        z++;
        if(z>=18)
        {
            irdata[p]=irtime;
            irtime=0;
            p++;
            if(p==17)
            {
                new_code=1;
                p=0;
				TR1=0;
				Ircordpro();
            }	  
        }
        else 
            irtime=0;          
        
    }   
    else
    {
        irtime=0;
        startflag=1;
    }
}
/************************************************/
void Ircordpro(void)//������ֵ��������
{
    uchar i, j, k;
    uchar cord,value;
    EX1 = 0;
    k=1;
    for(i=0;i<2;i++)//����4���ֽ�
    {
     for(j=1;j<=8;j++) //����1���ֽ�8λ
    {
        cord=irdata[k];
    if(cord>=11&&cord<=16)//����ĳֵΪ1
    {
        value=value|0x80;
    }
    if(cord>=4&&cord<=9)
    {
        value=value;
    }
    if(j<8)
    {
        value=value>>1;
    }
        k++;
    }
        IRcord[i]=value;
        value=0;    
    }
	key_code=IRcord[1]; //
   EX1 = 1;
} 