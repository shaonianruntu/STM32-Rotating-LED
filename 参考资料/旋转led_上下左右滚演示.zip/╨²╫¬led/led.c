#include "led.h"

void delay(unsigned int i)
{
	while(i--);
}

void led_disp(unsigned int num)
{
	led1  = (num & (1<<0))  > 0 ? 0 : 1;
	led2  = (num & (1<<1))  > 0 ? 0 : 1;
	led3  = (num & (1<<2))  > 0 ? 0 : 1;
	led4  = (num & (1<<3))  > 0 ? 0 : 1;
	led5  = (num & (1<<4))  > 0 ? 0 : 1;
	led6  = (num & (1<<5))  > 0 ? 0 : 1;
	led7  = (num & (1<<6))  > 0 ? 0 : 1;
	led8  = (num & (1<<7))  > 0 ? 0 : 1;
	led9  = (num & (1<<8))  > 0 ? 0 : 1;
	led10 = (num & (1<<9))  > 0 ? 0 : 1;
	led11 = (num & (1<<10)) > 0 ? 0 : 1;
	led12 = (num & (1<<11)) > 0 ? 0 : 1;
	led13 = (num & (1<<12)) > 0 ? 0 : 1;
	led14 = (num & (1<<13)) > 0 ? 0 : 1;
	led15 = (num & (1<<14)) > 0 ? 0 : 1;
	led16 = (num & (1<<15)) > 0 ? 0 : 1;
}



/*************************** End of file ****************************/