#include "tim.h"
#include "led.h"

#define FOSC 6197000L	  			// use internal oscillator @6.197MHz
//#define MODE1T                    //Timer clock mode, comment this line is 12T mode, uncomment is 1T mode


#ifdef MODE1T
#define T1MS (65536-FOSC/1000)      //1ms timer calculation method in 1T mode
#else
#define T1MS (65536-FOSC/12/1000)   //1ms timer calculation method in 12T mode
#endif


void tim0_init(void)
{
    TMOD = 0x01;                    //set timer0 as mode1 (16-bit)
    TL0 = T1MS;                     //initial timer0 low byte
    TH0 = T1MS >> 8;                //initial timer0 high byte
    TR0 = 1;                        //timer0 start running
    ET0 = 1;                        //enable timer0 interrupt
    EA = 1;                         //open global interrupt switch	
}


void tim0_irq(void) interrupt 1
{
	static unsigned int cnt = 0;
    TL0 = T1MS;                     //reload timer0 low byte
    TH0 = T1MS >> 8;                //reload timer0 high byte
	
	if(++ cnt <= 1000)
	{
		led_disp(0x5555);
	}
	else if( cnt > 1000 && cnt <= 2000)
	{
		led_disp(0xaaaa);
	}
	else
	{
		cnt = 0;
	}	
}




